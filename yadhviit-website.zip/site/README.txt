YadhviIT Services — website
===========================

TO PUBLISH
Upload every file in this folder to your host, keeping them in the same
directory. index.html expects the images to sit alongside it.

Easiest options (all free, HTTPS included):
  - Cloudflare Pages or Netlify: drag this folder onto their dashboard.
  - GitHub Pages: commit the folder, enable Pages in repo settings.
Then point yadhviit.com at the host with the DNS record they give you.

FILES
  index.html              The site. Self-contained apart from the images.
  favicon.png             Browser tab icon.
  logo-mark.png           The swoosh on its own. Used as the hero graphic.
  logo-lockup-light.png   Compact horizontal logo, for DARK backgrounds.
                          Used in the header and footer.
  logo-lockup.png         Same lockup, for LIGHT backgrounds.
  logo-full.png           Your original logo, unmodified.
  logo-light.png          Your original logo recoloured for dark backgrounds.

NOTE ON THE LOGO
All images here are derived from the 878x456 PNG supplied. That is fine at
current sizes, but if you have the original vector file (.ai, .eps or .svg),
use it instead — it will stay sharp on any screen and at any size.

EDITING COPY
All text is in index.html. Search for the sentence you want to change.
The four process stages under "How we work" were drafted, not supplied —
check they match how you actually run an engagement.
